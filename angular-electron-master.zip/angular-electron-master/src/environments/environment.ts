export const AppConfig = {
  production: false,
  environment: 'LOCAL'
};
